<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        User::factory()->create([
            'name' => 'Administrator Portal',
            'email' => 'admin@portal.test',
            'password' => bcrypt('admin123'),
        ]);

        $this->call([
            ServiceSeeder::class,
            ProfileSeeder::class,
        ]);
    }
}
